screen_dimensions = None
screen_width = None
screen_height = None
hud_side = None
hud_scale = None
hud_margin_v = None

hud_geometry = None

tmp = ""
