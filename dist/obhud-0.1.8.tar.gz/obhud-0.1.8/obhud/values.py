ver_string = "0.1.8"
whatsnew = " *** NEW: Timer/Stopwatch *** Run --autoconfig tint2 to add the executor"

screen_dimensions = None
screen_width = None
screen_height = None
hud_side = None
hud_scale = None
hud_margin_v = None

hud_geometry = None

tmp = ""

volume_up = ''
volume_down = ''
volume_toggle = ''

brightness_up = ''
brightness_down = ''
touchpad_on = ''
touchpad_off = ''

preferences_file = ""
preferences = None
screen_primary = ""
screen_secondary = ""

dialog_action = None
